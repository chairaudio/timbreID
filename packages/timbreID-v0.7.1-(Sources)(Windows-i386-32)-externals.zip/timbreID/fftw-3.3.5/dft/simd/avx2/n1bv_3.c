/* Generated automatically.  DO NOT EDIT! */
#define SIMD_HEADER "simd-avx2.h"
#include "../common/n1bv_3.c"
