/* Generated automatically.  DO NOT EDIT! */
#define SIMD_HEADER "simd-avx.h"
#include "../common/q1bv_8.c"
