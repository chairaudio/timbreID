/* Generated automatically.  DO NOT EDIT! */
#define SIMD_HEADER "simd-altivec.h"
#include "../common/t1fuv_2.c"
