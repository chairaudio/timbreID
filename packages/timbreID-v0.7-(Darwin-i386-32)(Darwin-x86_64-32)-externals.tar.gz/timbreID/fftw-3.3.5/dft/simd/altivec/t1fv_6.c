/* Generated automatically.  DO NOT EDIT! */
#define SIMD_HEADER "simd-altivec.h"
#include "../common/t1fv_6.c"
