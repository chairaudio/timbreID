/* Generated automatically.  DO NOT EDIT! */
#define SIMD_HEADER "simd-altivec.h"
#include "../common/q1fv_2.c"
