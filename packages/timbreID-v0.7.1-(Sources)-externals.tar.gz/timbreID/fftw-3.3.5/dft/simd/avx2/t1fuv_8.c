/* Generated automatically.  DO NOT EDIT! */
#define SIMD_HEADER "simd-avx2.h"
#include "../common/t1fuv_8.c"
